"print.gamex" <-
  function(x,...)
  {
    print(x$coefficients)
    invisible()
  }

