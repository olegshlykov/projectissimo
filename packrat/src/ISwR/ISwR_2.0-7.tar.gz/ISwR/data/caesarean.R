caesar.shoe<-matrix(c(5,7,6,7,8,10,17,28,36,41,46,140),
 	nrow=2,byrow=TRUE)
rownames(caesar.shoe)<-c("Yes","No")
colnames(caesar.shoe)<-c("<4",4,4.5,5,5.5,"6+")
