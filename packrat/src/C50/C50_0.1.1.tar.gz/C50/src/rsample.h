#ifndef _RSAMPLE_H_
#define _RSAMPLE_H_
int rpredictmain(int *trials, int *outputv, double *confidencev);
void SetTrials(int *internal, int *user);
#endif
